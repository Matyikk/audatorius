﻿## Duplikált tesztek a Test Explorer-ben
Az **NUnit 3 VS Test Adapter** ismert hibája, hogy amennyiben a *TestFixture*-be a *TestName* értéket kap, akkor a **Test Explorer**-ben kétszer fognak megjelenni a tesztek.
Issue: https://github.com/nunit/nunit3-vs-adapter/issues/729