﻿namespace OE.ALGA.Sandbox
{
    internal class Program
    {
        static void Main()
        {
        }
    }
}