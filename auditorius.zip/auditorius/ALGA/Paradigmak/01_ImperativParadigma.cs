﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;


namespace OE.ALGA.Paradigmak
{
    //1. heti labor feladat - Tesztek: 01_ImperativParadigmaTesztek.cs
    //1.feladat
    public interface IVegrehajthato
    {
        void Vegrehajtas();
    }

    // 3. feladat interface
    public interface IFuggo
    {
        bool FuggosegTeljesul { get; }
    }

    // Exception
    public class TaroloMegteltKivetel : Exception
    {
        public TaroloMegteltKivetel() : base("A tároló megtelt, nem lehet több elemet felvenni.")
        {
        }

        public TaroloMegteltKivetel(string message) : base(message)
        {
        }
    }

    // 2. Feladat
    public class FeladatTarolo<T> : IEnumerable<T> where T : IVegrehajthato
    {
        public T[] tarolo;
        public int n;
        public FeladatTarolo(int meret)
        {
            tarolo = new T[meret];
            n = 0;
        }

        public void Felvesz(T elem)
        {
            if (n < tarolo.Length)
            {
                tarolo[n] = elem;
                n++;
            }
            else
            {
                throw new TaroloMegteltKivetel();
            }
        }
        public int Meret => tarolo.Length;

        public virtual void MindentVegrehajt()
        {
            for (int i = 0; i < n; i++)
            {
                tarolo[i].Vegrehajtas();
            }
        }

        // 5.feladat
        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < n; i++)
            {
                yield return tarolo[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    // 4. Feladat
    public class FuggoFeladatTarolo<T> : FeladatTarolo<T> where T : IVegrehajthato, IFuggo
    {
        public FuggoFeladatTarolo(int méret) : base(méret)
        {

        }

        public override void MindentVegrehajt()
        {
            for (int i = 0; i < n; i++)
            {
                if (tarolo[i].FuggosegTeljesul)
                {
                    tarolo[i].Vegrehajtas();
                }
            }
        }
    }

    ////1. feladat
    //public interface IVegrehajthato
    //{
    //    public void Vegrehajtas()
    //    {

    //    }
    //}
    //public class TaroloMegteltKivetel : Exception
    //{
    //    public TaroloMegteltKivetel() : base("A tároló megtelt, nem lehet több elemet felvenni.")
    //    {
    //    }
    //}
    ////2.feladat
    //public class FeladatTarolo<T> : IEnumerable<T> where T : IVegrehajthato
    //{
    //    protected T[] tarolo;
    //    int n;
    //    public FeladatTarolo(int meret)
    //    {
    //        tarolo = new T[meret];
    //        n = 0;
    //    }



    //    public void Felvesz(T elem)
    //    {
    //        if (n < tarolo.Length)
    //        {
    //            tarolo[n] = elem;
    //            n++;
    //        }
    //        else
    //        {
    //            throw new TaroloMegteltKivetel();
    //        }
    //    }
    //    public int Meret => tarolo.Length;


    //    public void MindentVegrehajt()
    //    {
    //        for (int i = 0; i < tarolo.Length; i++)
    //        {
    //            tarolo[i].Vegrehajtas();
    //        }
    //    }
    //    //5.feladat
    //    public IEnumerator<T> GetEnumerator()
    //    {
    //        for (int i = 0; i < n; i++)
    //        {
    //            yield return tarolo[i];
    //        }
    //    }
    //    IEnumerator IEnumerable.GetEnumerator()
    //    {
    //        return GetEnumerator();
    //    }



    //}
    ////3.feladat
    //public interface IFuggo
    //{
    //    public bool FuggosegTeljesul { get; }
    //}
    ////4. feladat
    //public class FuggoFeladatTarolo<T> : FeladatTarolo<T> where T : IVegrehajthato, IFuggo
    //{
    //    public FuggoFeladatTarolo(int meret) : base(meret)
    //    {

    //    }
    //    public new void MindentVegrehajt()
    //    {
    //        for (int i = 0; i < this.Meret; i++)
    //        {


    //            if (tarolo[i].FuggosegTeljesul)
    //            {
    //                tarolo[i].Vegrehajtas();
    //            }
    //        }
    //    }
    //}





}



