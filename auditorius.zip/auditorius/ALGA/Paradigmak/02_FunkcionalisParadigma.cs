﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;

namespace OE.ALGA.Paradigmak
{
    // 2. heti labor feladat - Tesztek: 02_FunkcionálisParadigmaTesztek.cs



    public class FeltetelesFeladatTarolo<T> : FeladatTarolo<T>, IEnumerable<T>
    where T : IVegrehajthato
    {
        
        public FeltetelesFeladatTarolo(int meret) : base(meret)
        {
        }



        public void FeltetelesVegrehajtas(Func<T, bool> feltetel)
        {
            for (int i = 0; i < n; i++)
                if (feltetel(tarolo[i]))
                {
                    tarolo[i].Vegrehajtas();
                    if (feltetel(tarolo[i]))
                    {
                        tarolo[i].Vegrehajtas();
                    }
                }
        }
        public Func<T, bool> BejaroFeltetel { get; set; }

        public IEnumerator<T> BejaroLetrehozas()
        {
            Func<T, bool> predicate = BejaroFeltetel ?? (x => true);
            return new FeltetelesFeladatTaroloBejaro<T>(tarolo, n, predicate);
        }

        //gg
        public IEnumerator<T> GetEnumerator()
        {
            return BejaroLetrehozas();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    public class FeltetelesFeladatTaroloBejaro<T> : IEnumerator<T>
    {
        private T[] tarolo;
        private int n;
        private int aktualisIndex;
        private Func<T, bool> feltetel;

        public T Current => tarolo[aktualisIndex];

        object IEnumerator.Current => Current;

        public FeltetelesFeladatTaroloBejaro(T[] tarolo, int n, Func<T, bool> feltetel)
        {
            this.tarolo = tarolo;
            this.n = n;
            this.feltetel = feltetel;
            Reset();
        }

        public bool MoveNext()
        {
            aktualisIndex++;
            while (aktualisIndex < n && !feltetel(tarolo[aktualisIndex]))
            {
                aktualisIndex++;
            }

            return aktualisIndex < n;
        }

        public void Reset()
        {
            aktualisIndex = -1;
        }

        public void Dispose()
        {
        }
        
    }
        
}
