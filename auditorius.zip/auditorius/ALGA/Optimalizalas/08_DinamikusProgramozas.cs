﻿using System;

namespace OE.ALGA.Optimalizalas
{
    public class DinamikusHatizsakPakolas
    {
        private HatizsakProblema problema;

        public int LepesSzam { get; private set; }

        public DinamikusHatizsakPakolas(HatizsakProblema problema)
        {
            this.problema = problema;
        }


        /// <summary>
        /// ////////////////////////////////////////
        /// </summary>
        /// <returns></returns>
        private float[,] TablazatFeltoltes()
        {




            int n = problema.n;
            int Wmax = problema.Wmax;
            int[] w = problema.w;
            float[] p = problema.p;

            float[,] F = new float[n + 1, Wmax + 1];

            LepesSzam = 0;

            for (int t = 0; t <= n; t++)
            {
                for (int h = 0; h <= Wmax; h++)
                {
                    if (h == 0 || t == 0)
                    {
                        F[t, h] = 0;
                    }
                    else if (h < w[t - 1])
                    {
                        F[t, h] = F[t - 1, h];
                        LepesSzam++;
                    }
                    else
                    {
                        float nelkule = F[t - 1, h];
                        float vele = F[t - 1, h - w[t - 1]] + p[t - 1];
                        F[t, h] = Math.Max(nelkule, vele);
                        LepesSzam++;
                    }
                }
            }

            return F;
        }

        public float OptimalisErtek()
        {
            float[,] F = TablazatFeltoltes();
            return F[problema.n, problema.Wmax];
        }

        public bool[] OptimalisMegoldas()
        {
            int n = problema.n;
            int Wmax = problema.Wmax;
            int[] w = problema.w;
            float[] p = problema.p;

            float[,] F = TablazatFeltoltes();

            if (n == 0)
            {
                return new bool[0];
            }




            bool[] megoldas = new bool[n];
            int aktualisKapacitas = Wmax;

            for (int t = n; t >= 1; t--)
            {
                if (aktualisKapacitas >= w[t - 1] &&
                    F[t, aktualisKapacitas] != F[t - 1, aktualisKapacitas])
                {
                    megoldas[t - 1] = true;
                    aktualisKapacitas -= w[t - 1];
                }
                else
                {


                    megoldas[t - 1] = false;
                }
            }

            return megoldas;
        }
    }
}