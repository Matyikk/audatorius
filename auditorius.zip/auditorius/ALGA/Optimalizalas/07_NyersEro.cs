﻿using System;

namespace OE.ALGA.Optimalizalas
{
    
        public class HatizsakProblema
        {
            public int n { get; }
            public int Wmax { get; }
            public int[] w { get; }
            public float[] p { get; }

            public HatizsakProblema(int n, int Wmax, int[] w, float[] p)
            {
                this.n = n;
                this.Wmax = Wmax;
                this.w = w;
                this.p = p;
            if (n < 0)
                    throw new ArgumentException("n nem lehet negatív.");
                if (w == null || p == null)
                    throw new ArgumentNullException();
                if (w.Length != n || p.Length != n)
                    throw new ArgumentException("A tömbök hossza nem egyezik n-nel.");

                
            }

            public int OsszSuly(bool[] pakolas)
            {
                if (pakolas == null)
                    throw new ArgumentNullException(nameof(pakolas));

                if (n == 0)
                    return 0;

                if (pakolas.Length != n)
                    throw new ArgumentException("A pakolás hossza nem egyezik n-nel.");

                int ossz = 0;
                for (int i = 0; i < n; i++)
                {
                    if (pakolas[i])
                        ossz += w[i];
                }
                return ossz;
            }

            public float OsszErtek(bool[] pakolas)
            {
                if (pakolas == null)
                    throw new ArgumentNullException(nameof(pakolas));

                if (n == 0)
                    return 0;

                if (pakolas.Length != n)
                    throw new ArgumentException("A pakolás hossza nem egyezik n-nel.");

                float ossz = 0;
                for (int i = 0; i < n; i++)
                {
                    if (pakolas[i])
                        ossz += p[i];
                }
                return ossz;
            }

            public bool Ervenyes(bool[] pakolas)
            {
                if (pakolas == null)
                    throw new ArgumentNullException(nameof(pakolas));

                if (n == 0)
                    return true;

                if (pakolas.Length != n)
                    throw new ArgumentException("A pakolás hossza nem egyezik n-nel.");

                return OsszSuly(pakolas) <= Wmax;
            }
        }
        public class NyersEro<T>
        {
            int m;
            Func<int, T> generator;
            Func<T, float> josag;

            public int LepesSzam { get; private set; }
            public NyersEro(int m, Func<int, T> generator, Func<T, float> josag)
            {
                this.m = m;

                this.generator = generator;

                this.josag = josag;

            }

            public T OptimalisMegoldas()
            {
                T o = generator(1);
                for (int i = 2; i <= m; i++)
                {
                    T x = generator(i);
                    LepesSzam++;
                    if (josag(x) > josag(o))
                        o = x;


                }
                return o;
            }


        }

        public class NyersEroHatizsakPakolas
        {
            private HatizsakProblema problema;
            public int LepesSzam { get; private set; }

            public NyersEroHatizsakPakolas(HatizsakProblema problema)
            {
                this.problema = problema;
            }

            public bool[] Generator(int i)
            {





                int n = problema.n;
                bool[] pakolas = new bool[n];
                int szam = i - 1;






                for (int j = 0; j < n; j++)
                {
                    pakolas[j] = (szam & (1 << j)) != 0;
                }
                return pakolas;
            }

            public float Josag(bool[] pakolas)
            {
                if (!problema.Ervenyes(pakolas))
                    return -1;


                return problema.OsszErtek(pakolas);
            }

            public bool[] OptimalisMegoldas()
            {
                int m = 1 << problema.n;
                var nyersEro = new NyersEro<bool[]>(m, Generator, Josag);
                var megoldas = nyersEro.OptimalisMegoldas();
                LepesSzam = nyersEro.LepesSzam;
                return megoldas;
            }

            public float OptimalisErtek()
            {
                var megoldas = OptimalisMegoldas();
                return Josag(megoldas);
            }
        }


    }
