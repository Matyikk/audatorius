﻿//using System;

//namespace OE.ALGA.Optimalizalas
//{
//    // 1. Visszalépéses optimalizáció általános osztály
//    public class VisszalepesesOptimalizacio<T>
//    {
//        protected int n;
//        protected int[] M;
//        protected T[,] R;
//        protected Func<int, T, bool> ft;
//        protected Func<int, T, T[], bool> fk;
//        protected Func<T[], double> josag;

//        public int LepesSzam { get; protected set; }

//        public VisszalepesesOptimalizacio(
//            int n,
//            int[] M,
//            T[,] R,
//            Func<int, T, bool> ft,
//            Func<int, T, T[], bool> fk,
//            Func<T[], double> josag)
//        {
//            this.n = n;
//            this.M = M;
//            this.R = R;
//            this.ft = ft;
//            this.fk = fk;
//            this.josag = josag;
//            this.LepesSzam = 0;
//        }

//        // Backtrack rekurzív metódus - JEGYZET ALAPJÁN
//        protected virtual void Backtrack(int szint, T[] E, ref bool van, ref T[] O)
//        {
//            if (szint == n)
//            {
//                // Teljes megoldást értünk el
//                LepesSzam++;

//                if (!van)
//                {
//                    // Első megoldás
//                    van = true;
//                    Array.Copy(E, O, n);
//                }
//                else
//                {
//                    // Van már megoldás, összehasonlítjuk
//                    if (josag(E) > josag(O))
//                    {
//                        Array.Copy(E, O, n);
//                    }
//                }
//            }
//            else
//            {
//                // Próbáljuk az összes lehetséges részmegoldást ezen a szinten
//                for (int i = 0; i < M[szint]; i++)
//                {
//                    T r = R[szint, i];

//                    // Ellenőrizzük a korlát függvényeket
//                    if (ft(szint, r) && fk(szint, r, E))
//                    {
//                        E[szint] = r;
//                        Backtrack(szint + 1, E, ref van, ref O);
//                    }
//                }
//            }
//        }

//        // Optimális megoldás keresése
//        public T[] OptimalisMegoldas()
//        {
//            LepesSzam = 0;
//            T[] E = new T[n];
//            T[] O = new T[n];
//            bool van = false;

//            Backtrack(0, E, ref van, ref O);

//            return O;
//        }
//    }

//    // 2. Visszalépéses hátizsák pakolás
//    public class VisszalepesesHatizsakPakolas
//    {
//        protected HatizsakProblema problema;
//        protected bool[] optimalismegoldas;

//        public int LepesSzam { get; protected set; }

//        public VisszalepesesHatizsakPakolas(HatizsakProblema problema)
//        {
//            this.problema = problema;
//            this.LepesSzam = 0;
//            this.optimalismegoldas = null;
//        }

//        // Optimális megoldás keresése
//        public virtual bool[] OptimalisMegoldas()
//        {
//            if (optimalismegoldas != null)
//            {
//                return optimalismegoldas;
//            }

//            // M tömb: minden szinten 2 lehetőség (true/false)
//            int[] M = new int[problema.n];
//            for (int i = 0; i < problema.n; i++)
//            {
//                M[i] = 2;
//            }

//            // R tömb: minden szinten [true, false]
//            bool[,] R = new bool[problema.n, 2];
//            for (int i = 0; i < problema.n; i++)
//            {
//                R[i, 0] = true;   // Betesszük a tárgyat
//                R[i, 1] = false;  // Nem tesszük be
//            }

//            // ft: első korlát függvény - mindig igaz (minden részmegoldás választható)
//            Func<int, bool, bool> ft = (szint, r) => true;

//            // fk: második korlát függvény - kapacitás ellenőrzés
//            Func<int, bool, bool[], bool> fk = (szint, r, E) =>
//            {
//                if (!r) return true; // Ha nem tesszük be, mindig OK

//                // Ha betesszük, ellenőrizzük a kapacitást
//                int aktualisSuly = 0;
//                for (int i = 0; i < szint; i++)
//                {
//                    if (E[i])
//                    {
//                        aktualisSuly += problema.w[i];
//                    }
//                }
//                aktualisSuly += problema.w[szint];

//                return aktualisSuly <= problema.Wmax;
//            };

//            // Jóság függvény
//            Func<bool[], double> josag = (pakolas) =>
//            {
//                if (pakolas == null || pakolas.Length != problema.n)
//                {
//                    return -1;
//                }

//                if (!problema.Ervenyes(pakolas))
//                {
//                    return -1;
//                }
//                return problema.OsszErtek(pakolas);
//            };

//            // Visszalépéses optimalizáció létrehozása
//            VisszalepesesOptimalizacio<bool> optimalizalo = new VisszalepesesOptimalizacio<bool>(
//                problema.n,
//                M,
//                R,
//                ft,
//                fk,
//                josag
//            );

//            // Optimális megoldás keresése
//            optimalismegoldas = optimalizalo.OptimalisMegoldas();
//            LepesSzam = optimalizalo.LepesSzam;

//            return optimalismegoldas;
//        }

//        // Optimális érték
//        public double OptimalisErtek()
//        {
//            if (optimalismegoldas == null)
//            {
//                OptimalisMegoldas();
//            }

//            return problema.OsszErtek(optimalismegoldas);
//        }
//    }

//    // 3. Szétválasztás és korlátozás optimalizáció
//    public class SzetvalasztasEsKorlatozasOptimalizacio<T> : VisszalepesesOptimalizacio<T>
//    {
//        protected Func<int, T[], double> fb;

//        public SzetvalasztasEsKorlatozasOptimalizacio(
//            int n,
//            int[] M,
//            T[,] R,
//            Func<int, T, bool> ft,
//            Func<int, T, T[], bool> fk,
//            Func<T[], double> josag,
//            Func<int, T[], double> fb)
//            : base(n, M, R, ft, fk, josag)
//        {
//            this.fb = fb;
//        }

//        // Felülírt Backtrack metódus szétválasztás-korlátozással - JEGYZET ALAPJÁN
//        protected override void Backtrack(int szint, T[] E, ref bool van, ref T[] O)
//        {
//            if (szint == n)
//            {
//                // Teljes megoldást értünk el
//                LepesSzam++;

//                if (!van)
//                {
//                    van = true;
//                    Array.Copy(E, O, n);
//                }
//                else
//                {
//                    if (josag(E) > josag(O))
//                    {
//                        Array.Copy(E, O, n);
//                    }
//                }
//            }
//            else
//            {
//                // Próbáljuk az összes lehetséges részmegoldást
//                for (int i = 0; i < M[szint]; i++)
//                {
//                    T r = R[szint, i];

//                    // Ellenőrizzük a korlát függvényeket
//                    if (ft(szint, r) && fk(szint, r, E))
//                    {
//                        E[szint] = r;

//                        // Szétválasztás és korlátozás: felső becslés
//                        double becslés = fb(szint + 1, E);

//                        // Csak akkor folytatjuk, ha a becslés ígéretesebb mint az eddigi legjobb
//                        if (!van || becslés > josag(O))
//                        {
//                            Backtrack(szint + 1, E, ref van, ref O);
//                        }
//                    }
//                }
//            }
//        }
//    }

//    // 4. Szétválasztás és korlátozás hátizsák pakolás
//    public class SzetvalasztasEsKorlatozasHatizsakPakolas : VisszalepesesHatizsakPakolas
//    {
//        public SzetvalasztasEsKorlatozasHatizsakPakolas(HatizsakProblema problema)
//            : base(problema)
//        {
//        }

//        // Felülírt OptimalisMegoldas szétválasztás-korlátozással
//        public override bool[] OptimalisMegoldas()
//        {
//            if (optimalismegoldas != null)
//            {
//                return optimalismegoldas;
//            }

//            // M tömb: minden szinten 2 lehetőség
//            int[] M = new int[problema.n];
//            for (int i = 0; i < problema.n; i++)
//            {
//                M[i] = 2;
//            }

//            // R tömb: minden szinten [true, false]
//            bool[,] R = new bool[problema.n, 2];
//            for (int i = 0; i < problema.n; i++)
//            {
//                R[i, 0] = true;
//                R[i, 1] = false;
//            }

//            // Korlát függvények
//            Func<int, bool, bool> ft = (szint, r) => true;

//            Func<int, bool, bool[], bool> fk = (szint, r, E) =>
//            {
//                if (!r) return true;

//                int aktualisSuly = 0;
//                for (int i = 0; i < szint; i++)
//                {
//                    if (E[i])
//                    {
//                        aktualisSuly += problema.w[i];
//                    }
//                }
//                aktualisSuly += problema.w[szint];

//                return aktualisSuly <= problema.Wmax;
//            };

//            // Jóság függvény
//            Func<bool[], double> josag = (pakolas) =>
//            {
//                if (pakolas == null || pakolas.Length != problema.n)
//                {
//                    return -1;
//                }

//                if (!problema.Ervenyes(pakolas))
//                {
//                    return -1;
//                }
//                return problema.OsszErtek(pakolas);
//            };

//            // Felső becslés függvény - az eddig elért érték + hátralévő optimista becslés
//            Func<int, bool[], double> fb = (szint, E) =>
//            {
//                // Jelenlegi pakolás értéke
//                double jelenlegiErtek = 0;
//                int felhasznaltSuly = 0;

//                for (int i = 0; i < szint; i++)
//                {
//                    if (E[i])
//                    {
//                        jelenlegiErtek += problema.p[i];
//                        felhasznaltSuly += problema.w[i];
//                    }
//                }

//                // Hátralévő kapacitás
//                int maradekKapacitas = problema.Wmax - felhasznaltSuly;

//                // Optimista becslés: minden hátralévő tárgyat beteszünk, ami belefér
//                double optimistaBecslés = 0;
//                for (int i = szint; i < problema.n; i++)
//                {
//                    if (problema.w[i] <= maradekKapacitas)
//                    {
//                        optimistaBecslés += problema.p[i];
//                        maradekKapacitas -= problema.w[i];
//                    }
//                }

//                return jelenlegiErtek + optimistaBecslés;
//            };

//            // Szétválasztás és korlátozás optimalizáció létrehozása
//            SzetvalasztasEsKorlatozasOptimalizacio<bool> optimalizalo =
//                new SzetvalasztasEsKorlatozasOptimalizacio<bool>(
//                    problema.n,
//                    M,
//                    R,
//                    ft,
//                    fk,
//                    josag,
//                    fb
//                );

//            // Optimális megoldás keresése
//            optimalismegoldas = optimalizalo.OptimalisMegoldas();
//            LepesSzam = optimalizalo.LepesSzam;

//            return optimalismegoldas;
//        }
//    }
//}