﻿using System;
using System.Collections;
using System.Collections.Generic;
using OE.ALGA.Adatszerkezetek.OE.ALGA.Adatszerkezetek;

namespace OE.ALGA.Adatszerkezetek
{
    // 3. heti labor feladat - Tesztek: 03_TombImplementacioTesztek.cs


    public class TombVerem<T> : Verem<T>
    {


        public T[] E;
        public int n;

        public TombVerem(int meret)
        {
            E = new T[meret];

        }


        public bool Ures
        {
            get
            {
                return n == 0;
            }
        }

        public void Felszabadit()
        {


            if (E != null)
            {
                for (int i = 0; i < n; i++)
                {
                    if (E[i] is IDisposable disposable)
                    {
                        disposable.Dispose();
                    }
                    E[i] = default(T); // Referencia törlése
                }
            }

            E = null;
            n = 0;
        }



        public virtual void Verembe(T ertek)
        {
            if (n >= E.Length)
            {
                throw new NincsHelyKivetel();
            }
            else
            {
                E[n] = ertek;
                n++;
            }




        }


        public T Verembol()
        {
            if (n <= 0)
            {
                throw new NincsElemKivetel();
            }
            else
            {
                n--;
                return E[n];
            }

        }

        public T Felso()
        {
            if (!Ures)
                return E[n - 1];
            else
                throw new NincsElemKivetel();
        }


    }
    //3.feladat
    public class TombSor<T> : Sor<T>
    {
        T[] E;
        int e = 0;
        int u = 0;
        int n = 0;

        public TombSor(int meret)
        {
            E = new T[meret];
        }

        public bool Ures
        {
            get { return n == 0; }
        }

        public T Elso()
        {
            if (!Ures)
                return E[e];
            else
                throw new NincsElemKivetel();
        }

        public void Sorba(T ertek)
        {
            if (n < E.Length)
            {
                E[u] = ertek;
                u = (u + 1) % E.Length;
                n++;
            }
            else
                throw new NincsHelyKivetel();
        }

        public T Sorbol()
        {

            if (n > 0)
            {
                T ertek = E[e];
                e = (e + 1) % E.Length;
                n--;
                return ertek;
            }
            else
                throw new NincsElemKivetel();
        }
    }


    public class TombLista<T> : Lista<T>, IEnumerable<T>
    {
        private T[] E;
        private int n;


        public int Elemszam => n;



        public TombLista(int meret = 10)
        {

            E = new T[meret];
            n = 0;
        }



        private void MeretNovel()
        {
            T[] ujTomb = new T[E.Length * 2];
            for (int i = 0; i < n; i++)
            {
                ujTomb[i] = E[i];
            }
            E = ujTomb;
        }



        public T Kiolvas(int index)
        {
            if (index < 0 || index >= n)
                throw new HibasIndexKivetel();
            return E[index];
        }


        public void Modosit(int index, T ertek)
        {
            if (index < 0 || index >= n)
                throw new HibasIndexKivetel();
            E[index] = ertek;
        }


        public void Hozzafuz(T ertek)
        {
            if (n >= E.Length)
                MeretNovel();
            E[n] = ertek;
            n++;
        }


        public virtual void Beszur(int index, T ertek)
        {
            if (index < 0 || index > n)
                throw new HibasIndexKivetel();
            if (n >= E.Length)
                MeretNovel();

            for (int i = n; i > index; i--)
            {
                E[i] = E[i - 1];
            }
            E[index] = ertek;
            n++;
        }


        public void Torol(T ertek)
        {
            int i = 0;
            while (i < n)
            {
                if (E[i].Equals(ertek))
                {
                    for (int j = i; j < n - 1; j++)
                    {
                        E[j] = E[j + 1];
                    }
                    n--;
                }
                else
                {
                    i++;
                }
            }
        }


        public void Bejar(Action<T> muvelet)
        {
            for (int i = 0; i < n; i++)
            {
                muvelet(E[i]);
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new TombListaEnumerator<T>(E, n);
        }


        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////6
    //

    public class TombListaEnumerator<T> : IEnumerator<T>
    {
        private T[] E;
        private int n;
        private int aktualisIndex;
        public T Current
        {
            get
            {
                if (aktualisIndex < 0 || aktualisIndex >= n)
                    throw new HibasIndexKivetel();
                return E[aktualisIndex];
            }
        }
        object IEnumerator.Current
        {
            get { return Current; }
        }

        public TombListaEnumerator(T[] tomb, int elemszam)
        {
            E = tomb;
            n = elemszam;
            aktualisIndex = -1;
        }
        public bool MoveNext()
        {
            aktualisIndex++;
            return aktualisIndex < n;
        }
        public void Reset()
        {
            aktualisIndex = -1;
        }
        public void Dispose()
        {

        }

    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////6
    ///
    public class TorolhetoVerem<T> : TombVerem<T> where T : IComparable<T>
    {
        public TorolhetoVerem(int meret) : base(meret)
        {
        }
        public void Torol(T ertek)
        {
            TombVerem<T> ideiglenes = new TombVerem<T>(E.Length);
            while (!this.Ures)
            {
                T aktualis = this.Verembol();
                if (!aktualis.Equals(ertek))
                {
                    ideiglenes.Verembe(aktualis);
                }
            }

            while (!ideiglenes.Ures)
            {
                this.Verembe(ideiglenes.Verembol());
            }
        }





    }
}