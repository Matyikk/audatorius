﻿using System;

namespace OE.ALGA.Adatszerkezetek
{
    public class Kupac<T>
    {
        protected T[] E;
        protected int n;
        protected Func<T, T, bool> nagyobbPrioritas;

        public Kupac(T[] E, int n, Func<T, T, bool> nagyobbPrioritas)
        {
            this.E = E;
            this.n = n;
            this.nagyobbPrioritas = nagyobbPrioritas;
            KupacotEpit();
        }

        public static int Bal(int i) => 2 * i;
        public static int Jobb(int i) => 2 * i + 1;
        public static int Szulo(int i) => i / 2;

        protected void Kupacol(int i)
        {
            int bal = Bal(i);
            int jobb = Jobb(i);
            int legnagyobb = i;

            if (bal < n && nagyobbPrioritas(E[bal], E[legnagyobb]))
            {
                legnagyobb = bal;
            }

            if (jobb < n && nagyobbPrioritas(E[jobb], E[legnagyobb]))
            {
                legnagyobb = jobb;
            }

            if (legnagyobb != i)
            {
                (E[i], E[legnagyobb]) = (E[legnagyobb], E[i]);
                Kupacol(legnagyobb);
            }
        }

        protected void KupacotEpit()
        {
            for (int i = n / 2 - 1; i >= 0; i--)
            {
                Kupacol(i);
            }
        }
    }

    public class KupacRendezes<T> : Kupac<T> where T : IComparable<T>
    {
        public KupacRendezes(T[] A)
            : base(A, A.Length, (x, y) => x.CompareTo(y) > 0)
        {
        }

        public void Rendezes()
        {
            int eredeti_n = n;

            for (int i = n - 1; i > 0; i--)
            {
                (E[0], E[i]) = (E[i], E[0]);
                n--;
                Kupacol(0);
            }

            n = eredeti_n;
        }
    }

    public class KupacPrioritasosSor<T> : Kupac<T>, PrioritasosSor<T>
    {
        public bool Ures => n == 0;

        public KupacPrioritasosSor(int meret, Func<T, T, bool> nagyobbPrioritas)
            : base(new T[meret], 0, nagyobbPrioritas)
        {
        }

        private void KulcsotFelvisz(int i)
        {
            while (i > 0 && nagyobbPrioritas(E[i], E[Szulo(i)]))
            {
                (E[i], E[Szulo(i)]) = (E[Szulo(i)], E[i]);
                i = Szulo(i);
            }
        }
     
        /// ////////////////////////////////////////////
       
        public void Sorba(T ertek)
        {
            if (n >= E.Length)
            {
                throw new NincsHelyKivetel();
            }

            E[n] = ertek;
            n++;
            KulcsotFelvisz(n - 1);
        }

        public T Sorbol()
        {
            if (Ures)
            {
                throw new NincsElemKivetel();
            }

            T max = E[0];
            E[0] = E[n - 1];
            n--;

            if (n > 0)
            {
                Kupacol(0);
            }

            return max;
        }




        public T Elso()
        {
            if (Ures)
            {
                throw new NincsElemKivetel();
            }

            return E[0];
        }

        public void Frissit(T ertek)
        {
            int index = -1;
            for (int i = 0; i < n; i++)
            {
                if (E[i].Equals(ertek))
                {
                    index = i;
                    break;
                }
            }
            /////////////////////////////////////////////
            if (index == -1)
            {
                throw new NincsElemKivetel();
            }

            KulcsotFelvisz(index);
            Kupacol(index);
        }

        public void Felszabadit()
        {
            E = null;
            n = 0;
        }
    }
}