﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace OE.ALGA.Adatszerkezetek
{
    public class LancElem<T>
    {
        public T tart;
        public LancElem<T> kov;

        public LancElem(T tart, LancElem<T>? kov)
        {
            this.tart = tart;
            this.kov = kov;
        }
    }
    
    public class LancoltVerem<T> : Verem<T>
    {
        LancElem<T>? fej;

        public LancoltVerem()
        {
            fej = null;
        }



        public bool Ures
        {
            get
            {
                return fej == null;
            }
        }

        public T Felso()
        {
            if (fej != null)
            {
                return fej.tart;
            }
            else throw new NincsElemKivetel();
        }

        public void Verembe(T ertek)
        {
            LancElem<T> uj = new LancElem<T>(ertek, fej);
            fej = uj;
        }

        public T Verembol()
        {
            if (fej != null)
            {
                T ertek = fej.tart;
                LancElem<T> q = fej;
                fej = fej.kov;
                return ertek;
            }
            else throw new NincsElemKivetel();
        }
    }
    //////////////////////////////////////////3. feladat
    public class LancoltSor<T> : Sor<T>
    {
        LancElem<T>? fej;
        LancElem<T>? vege;
        public bool Ures
        {
            get
            {
                return fej == null;
            }
        }
        public LancoltSor()
        {
            fej = null;
            vege = null;
        }


        public T Elso()
        {
            if (fej != null)
            {
                return fej.tart;
            }
            else throw new NincsElemKivetel();
        }

        public void Sorba(T ertek)
        {
            LancElem<T> uj = new LancElem<T>(ertek, null);
            if (vege != null)
            {
                vege.kov = uj;
            }
            else
            {
                fej = uj;
            }
            vege = uj;
        }

        public T Sorbol()
        {
            if (fej != null)
            {
                T ertek = fej.tart;
                LancElem<T> q = fej;
                fej = fej.kov;
                if (fej == null)
                {
                    vege = null;
                }
                return ertek;
            }
            else throw new NincsElemKivetel();
        }
    }
    ////////////////////////////////////4.. feladat
    public class LancoltLista<T> : Lista<T>, IEnumerable<T>
    {
        private LancElem<T>? fej = null;
        private int elemszam = 0;

        public int Elemszam => elemszam;

        private LancElem<T> ElemLeker(int index)
        {
            if (index < 0 || index >= Elemszam)
                throw new HibasIndexKivetel();

            LancElem<T> aktualis = fej!;
            for (int i = 0; i < index; i++)
                aktualis = aktualis.kov!;
            return aktualis;
        }
        public void Verembe(T ertek)
        {
            //fej = new LancElem<T>(ertek, fej);
            fej = new LancElem<T>(ertek, fej);
            elemszam++;
        }

        public T Kiolvas(int index)
        {
            return ElemLeker(index).tart;
        }

        public void Modosit(int index, T ertek)
        {
            ElemLeker(index).tart = ertek;
        }

        public void Hozzafuz(T ertek)
        {
            Beszur(Elemszam, ertek);
        }

        public void Beszur(int index, T ertek)
        {
            if (index < 0 || index > Elemszam)
                throw new HibasIndexKivetel();

            if (index == 0)
            {
                fej = new LancElem<T>(ertek, fej);
            }
            else
            {
                LancElem<T> elozo = ElemLeker(index - 1);
                elozo.kov = new LancElem<T>(ertek, elozo.kov);
            }
            elemszam++;
        }

        public void Torol(T ertek)
        {
            while (true)
            {
                LancElem<T>? aktualis = fej;
                LancElem<T>? elozo = null;
                bool talalt = false;

                while (aktualis != null)
                {
                    if (Equals(aktualis.tart, ertek))
                    {
                        if (elozo == null)
                        {
                            fej = aktualis.kov;
                        }
                        else
                        {
                            elozo.kov = aktualis.kov;
                        }
                        elemszam--;
                        talalt = true;
                        break;
                    }
                    elozo = aktualis;
                    aktualis = aktualis.kov;
                }

                if (!talalt)
                    break;
            }
       }

        public void Bejar(Action<T> muvelet)
        {
            LancElem<T>? aktualis = fej;
            while (aktualis != null)
            {
                muvelet(aktualis.tart);
                aktualis = aktualis.kov;
            }
        }

        public IEnumerable<T> BejaroLetrehozas()
        {
            return new LancoltListaBejaro<T>(fej);
        }

        // IEnumerable<T> támogatás a foreach-hez
        public IEnumerator<T> GetEnumerator()
        {
            LancElem<T>? aktualis = fej;
            while (aktualis != null)
            {
                yield return aktualis.tart;
                aktualis = aktualis.kov;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        }

        public class LancoltListaBejaro<T> : IEnumerable<T>
    {
            private LancElem<T>? fej;
            private LancElem<T>? aktualisElem;

            public LancoltListaBejaro(LancElem<T>? fej)
            {
                this.fej = fej;
                Alaphelyzet();
            }

        public T Aktualis => aktualisElem.tart;

            public void Alaphelyzet()
            {
                aktualisElem = fej;
            }

        public IEnumerator<T> GetEnumerator()
        {
            LancElem<T>? aktualis = fej;
            while (aktualis != null)
            {
                yield return aktualis.tart;
                aktualis = aktualis.kov;
            }
        }

        public bool Kovetkezo()
            {
                if (aktualisElem != null)
                {
                    aktualisElem = aktualisElem.kov;
                    return aktualisElem != null;
                }
                return false;
            }
        
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
    ///////////////////////////////////////////






}