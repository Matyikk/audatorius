﻿using System;
using OE.ALGA.Adatszerkezetek.OE.ALGA.Adatszerkezetek;

namespace OE.ALGA.Adatszerkezetek
{
    // 5. heti labor feladat - Tesztek: 05_BinarisKeresoFaTesztek.cs
    //

    namespace OE.ALGA.Adatszerkezetek
    {
        // 1. 
        internal class FaElem<T> where T : IComparable<T>
        {
            public T tart;
            public FaElem<T> bal;
            public FaElem<T> jobb;

            public FaElem(T tart, FaElem<T> bal, FaElem<T> jobb)
            {
                this.tart = tart;
                this.bal = bal;
                this.jobb = jobb;
            }
        }

        // 2. 
        public class FaHalmaz<T> : Halmaz<T> where T : IComparable<T>
        {
            private FaElem<T> gyoker;

            public FaHalmaz()
            {
                gyoker = null;
            }

            public void Felszabadit()
            {
                gyoker = null;
            }

            // 3. 
            public virtual void Beszur(T ertek)
            {
                gyoker = ReszfabaBeszur(gyoker, ertek);
            }

            private static FaElem<T> ReszfabaBeszur(FaElem<T> p, T ertek)
            {
                if (p == null)
                {
                    return new FaElem<T>(ertek, null, null);
                }

                int osszehasonlitas = ertek.CompareTo(p.tart);

                if (osszehasonlitas < 0)
                {
                    p.bal = ReszfabaBeszur(p.bal, ertek);
                }
                else if (osszehasonlitas > 0)
                {
                    p.jobb = ReszfabaBeszur(p.jobb, ertek);
                }
                

                return p;
            }

            // 4. 
            public bool Eleme(T ertek)
            {
                return ReszfaEleme(gyoker, ertek);
            }

            private static bool ReszfaEleme(FaElem<T> p, T ertek)
            {
                if (p == null)
                {
                    return false;
                }

                int osszehasonlitas = ertek.CompareTo(p.tart);

                if (osszehasonlitas < 0)
                {
                    return ReszfaEleme(p.bal, ertek);
                }
                else if (osszehasonlitas > 0)
                {
                    return ReszfaEleme(p.jobb, ertek);
                }
                else
                {
                    return true; //Megtaláltuk
                }
            }

            // 5.
            public virtual void Torol(T ertek)
            {
                if (!Eleme(ertek))
                {
                    throw new NincsElemKivetel();
                }

                gyoker = ReszfabolTorol(gyoker, ertek);
            }

            private static FaElem<T> ReszfabolTorol(FaElem<T> p, T ertek)
            {
                if (p == null)
                {
                    return null;
                }

                int osszehasonlitas = ertek.CompareTo(p.tart);

                if (osszehasonlitas < 0)
                {
                    p.bal = ReszfabolTorol(p.bal, ertek);
                    return p;
                }
                else if (osszehasonlitas > 0)
                {
                    p.jobb = ReszfabolTorol(p.jobb, ertek);
                    return p;
                }
                else
                {
                    // Megtaláltuk
                    if (p.bal == null && p.jobb == null)
                    {
                        
                        return null;
                    }
                    else if (p.bal == null)
                    {
                        
                        return p.jobb;
                    }
                    else if (p.jobb == null)
                    {
                        
                        return p.bal;
                    }
                    else
                    {
                        
                        return KetGyerekesTorles(p);
                    }
                }
            }

            private static FaElem<T> KetGyerekesTorles(FaElem<T> p)
            {
                
                FaElem<T> szulo = p;
                FaElem<T> aktualis = p.bal;

                while (aktualis.jobb != null)
                {
                    szulo = aktualis;
                    aktualis = aktualis.jobb;
                }

                
                p.tart = aktualis.tart;

               
                if (szulo == p)
                {
                
                    szulo.bal = aktualis.bal;
                }
                else
                {
                  
                    szulo.jobb = aktualis.bal;
                }

                return p;
            }

          
            public void Bejar(Action<T> muvelet)
            {
                ReszfaBejarasPreOrder(gyoker, muvelet);
            }

            private static void ReszfaBejarasPreOrder(FaElem<T> p, Action<T> muvelet)
            {
                if (p != null)
                {
                    muvelet(p.tart);
                    ReszfaBejarasPreOrder(p.bal, muvelet);
                    ReszfaBejarasPreOrder(p.jobb, muvelet);
                }
            }

            private static void ReszfaBejarasInOrder(FaElem<T> p, Action<T> muvelet)
            {
                if (p != null)
                {
                    ReszfaBejarasInOrder(p.bal, muvelet);
                    muvelet(p.tart);
                    ReszfaBejarasInOrder(p.jobb, muvelet);
                }
            }

            private static void ReszfaBejarasPostOrder(FaElem<T> p, Action<T> muvelet)
            {
                if (p != null)
                {
                    ReszfaBejarasPostOrder(p.bal, muvelet);
                    ReszfaBejarasPostOrder(p.jobb, muvelet);
                    muvelet(p.tart);
                }
            }
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////
    ///
    public class VisszavonoFaHalmaz<T> : FaHalmaz<T> where T : IComparable<T>
    {
        private TombVerem<T> undoVerem;

        //•	Cseréld ki az előzőleg létrehozott verem objektumot az újonnan létrehozott TorolhetoVerem<T> típusúra
        public VisszavonoFaHalmaz(int veremMeret)
        {
            undoVerem = new TorolhetoVerem<T>(veremMeret);
        }

        public override void Beszur(T ertek)
        {
            bool voltMarBenne = Eleme(ertek);
            if (!voltMarBenne)
            {
                base.Beszur(ertek);
                undoVerem.Verembe(ertek);
            }

        }

        public void Visszavon(T ertek)
        {
            if (undoVerem.Ures)
            {
                throw new NincsMitVisszaVonniKivetel();
            }
            else
            {
                T visszavontElem = undoVerem.Verembol();
                base.Torol(visszavontElem);
            }

        }

        public override void Torol(T ertek)
        {
            base.Torol(ertek);
            //•	Módosítsd a fától örökölt Torol műveletet, hogy a fából törlés mellett a veremből is törölje a kapott értéket (2)

            while (!undoVerem.Ures && undoVerem.Felso().CompareTo(ertek) == 0)
            {
                undoVerem.Verembol();
            }

                
        }
    }

    public class NincsMitVisszaVonniKivetel : Exception
    {
    }

}
