﻿using System;
using OE.ALGA.Adatszerkezetek.OE.ALGA.Adatszerkezetek;


namespace OE.ALGA.Adatszerkezetek
{

    public class SulyozottEgeszGrafEl : EgeszGrafEl, SulyozottGrafEl<int>
    {


        public float Suly { get; }

        public SulyozottEgeszGrafEl(int honnan, int hova, float suly)
            : base(honnan, hova)
        {
            this.Suly = suly;
        }
        //
        public override bool Equals(object obj)
        {
            if (obj is SulyozottEgeszGrafEl other)
            {
                return this.Honnan == other.Honnan &&
                       this.Hova == other.Hova &&
                       Math.Abs(this.Suly - other.Suly) < 0.0001f;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Honnan, Hova, Suly);
        }


    }
   
    /// //////////////////////////////////
    
    public class CsucsmatrixSulyozottEgeszGraf : SulyozottGraf<int, SulyozottEgeszGrafEl>
    {
        private int n;
        private float[,] M;

        public int CsucsokSzama => n;

        public int ElekSzama
        {
            get
            {
                int szamlalo = 0;
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {



                        if (!float.IsNaN(M[i, j]))
                        {
                            szamlalo++;
                        }
                    }
                }
                return szamlalo;
            }
        }

        public CsucsmatrixSulyozottEgeszGraf(int n)
        {
            this.n = n;
            this.M = new float[n, n];




            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    M[i, j] = float.NaN;
                }
            }
        }

        public Halmaz<int> Csucsok
        {
            get
            {
                FaHalmaz<int> csucsok = new FaHalmaz<int>();
                for (int i = 0; i < n; i++)
                {
                    csucsok.Beszur(i);
                }
                return csucsok;
            }
        }

        public Halmaz<SulyozottEgeszGrafEl> Elek
        {
            get
            {
                FaHalmaz<SulyozottEgeszGrafEl> elek = new FaHalmaz<SulyozottEgeszGrafEl>();
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (!float.IsNaN(M[i, j]))
                        {
                            elek.Beszur(new SulyozottEgeszGrafEl(i, j, M[i, j]));
                        }
                    }
                }
                return elek;
            }
        }




        public void UjEl(int honnan, int hova, float suly)
        {
            M[honnan, hova] = suly;
        }

        public bool VezetEl(int honnan, int hova)
        {
            return !float.IsNaN(M[honnan, hova]);


        }

        public float Suly(int honnan, int hova)
        {
            if (float.IsNaN(M[honnan, hova]))
            {
                throw new NincsElKivetel();
            }
            return M[honnan, hova];
        }

        public Halmaz<int> Szomszedai(int csúcs)
        {
            FaHalmaz<int> szomszedok = new FaHalmaz<int>();
            for (int j = 0; j < n; j++)
            {
                if (!float.IsNaN(M[csúcs, j]))
                {
                    szomszedok.Beszur(j);
                }
            }
            return szomszedok;
        }
    }





    public static class Utkereses
    {
        public static Szotar<V, float> Dijkstra<V, E>(SulyozottGraf<V, E> g, V start)
            where V : IComparable<V>
            where E : SulyozottGrafEl<V>
        {
            HasitoSzotarTulcsordulasiTerulettel<V, float> d =
                new HasitoSzotarTulcsordulasiTerulettel<V, float>(100);

            FaHalmaz<V> F = new FaHalmaz<V>();

            g.Csucsok.Bejar(v =>
            {
                d.Beir(v, float.PositiveInfinity);
            });
            d.Beir(start, 0.0f);

            KupacPrioritasosSor<V> Q = new KupacPrioritasosSor<V>(
                1000,
                (x, y) => d.Kiolvas(x) < d.Kiolvas(y)
            );

            g.Csucsok.Bejar(v => Q.Sorba(v));

            while (!Q.Ures)
            {
                V u = Q.Sorbol();
                F.Beszur(u);

                g.Szomszedai(u).Bejar(v =>
                {
                    if (!F.Eleme(v))
                    {
                        float ujTavolsag = d.Kiolvas(u) + g.Suly(u, v);
                        if (ujTavolsag < d.Kiolvas(v))
                        {
                            d.Beir(v, ujTavolsag);
                            Q.Frissit(v);
                        }
                    }
                });
            }

            return d;
        }
    }

    public static class FeszitofaKereses
    {
        public static Szotar<V, V> Prim<V, E>(SulyozottGraf<V, E> g, V start)
            where V : IComparable<V>
            where E : SulyozottGrafEl<V>
        {
            HasitoSzotarTulcsordulasiTerulettel<V, float> K =
                new HasitoSzotarTulcsordulasiTerulettel<V, float>(100);

            HasitoSzotarTulcsordulasiTerulettel<V, V> szulo =
                new HasitoSzotarTulcsordulasiTerulettel<V, V>(100);

            FaHalmaz<V> F = new FaHalmaz<V>();
            FaHalmaz<V> sorbanVan = new FaHalmaz<V>();

            g.Csucsok.Bejar(v =>
            {
                K.Beir(v, float.PositiveInfinity);
            });
            K.Beir(start, 0.0f);

            KupacPrioritasosSor<V> S = new KupacPrioritasosSor<V>(
                1000,
                (x, y) => K.Kiolvas(x) < K.Kiolvas(y)
            );





            g.Csucsok.Bejar(v =>
            {
                S.Sorba(v);
                sorbanVan.Beszur(v);
            });

            while (!S.Ures)
            {
                V u = S.Sorbol();
                sorbanVan.Torol(u);
                F.Beszur(u);

                g.Szomszedai(u).Bejar(v =>
                {
                    if (sorbanVan.Eleme(v))
                    {
                        float w = g.Suly(u, v);
                        if (w < K.Kiolvas(v))
                        {
                            szulo.Beir(v, u);
                            K.Beir(v, w);
                            S.Frissit(v);
                        }
                    }
                });
            }





            return szulo;
        }

        public static Halmaz<E> Kruskal<V, E>(SulyozottGraf<V, E> g)
            where V : IComparable<V>
            where E : SulyozottGrafEl<V>, IComparable<E>
        {
            FaHalmaz<E> A = new FaHalmaz<E>();

            HasitoSzotarTulcsordulasiTerulettel<V, V> szulo =
                new HasitoSzotarTulcsordulasiTerulettel<V, V>(100);

            g.Csucsok.Bejar(v => szulo.Beir(v, v));

            V Kereso(V x)
            {
                V sz = szulo.Kiolvas(x);
                if (!sz.Equals(x))
                {
                    sz = Kereso(sz);
                    szulo.Beir(x, sz);
                }
                return sz;
            }



            void Unio(V x, V y)
            {
                V gyoker_x = Kereso(x);
                V gyoker_y = Kereso(y);
                szulo.Beir(gyoker_x, gyoker_y);
            }

            TombLista<E> rendezettElek = new TombLista<E>();
            g.Elek.Bejar(e => rendezettElek.Hozzafuz(e));

            for (int i = 0; i < rendezettElek.Elemszam - 1; i++)
            {
                for (int j = i + 1; j < rendezettElek.Elemszam; j++)
                {
                    E e1 = rendezettElek.Kiolvas(i);
                    E e2 = rendezettElek.Kiolvas(j);

                    if (e1.Suly > e2.Suly)
                    {
                        rendezettElek.Modosit(i, e2);
                        rendezettElek.Modosit(j, e1);
                    }
                }
            }

            for (int i = 0; i < rendezettElek.Elemszam; i++)
            {
                E e = rendezettElek.Kiolvas(i);
                V u = e.Honnan;
                V v = e.Hova;

                if (!Kereso(u).Equals(Kereso(v)))
                {
                    A.Beszur(e);
                    Unio(u, v);
                }
            }

            return A;
        }
    }
}