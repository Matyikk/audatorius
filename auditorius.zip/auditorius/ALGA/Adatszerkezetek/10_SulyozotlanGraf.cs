﻿using System;
using OE.ALGA.Adatszerkezetek.OE.ALGA.Adatszerkezetek;

namespace OE.ALGA.Adatszerkezetek
{
    // 1.
    public class EgeszGrafEl : GrafEl<int>, IComparable<EgeszGrafEl>
    {
        public int Honnan { get; }
        public int Hova { get; }

        public EgeszGrafEl(int honnan, int hova)
        {
            this.Honnan = honnan;
            this.Hova = hova;
        }

       
        public int CompareTo(EgeszGrafEl other)
        {
            if (other == null) return 1;

          
            if (this.Honnan != other.Honnan)
            {
                return this.Honnan.CompareTo(other.Honnan);
            }

            return this.Hova.CompareTo(other.Hova);
        }

        public override bool Equals(object obj)
        {
            if (obj is EgeszGrafEl other)
            {
                return this.Honnan == other.Honnan && this.Hova == other.Hova;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Honnan, Hova);
        }
    }

    // 2. 
    public class CsucsmatrixSulyozatlanEgeszGraf : SulyozatlanGraf<int, EgeszGrafEl>
    {
        private int n;
        private bool[,] M;

        public int CsucsokSzama => n;

        public int ElekSzama
        {
            get
            {
                int szamlalo = 0;
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (M[i, j])
                        {
                            szamlalo++;
                        }
                    }
                }
                return szamlalo;
            }
        }

        public CsucsmatrixSulyozatlanEgeszGraf(int n)
        {
            this.n = n;
            this.M = new bool[n, n];
        }

   
        public Halmaz<int> Csucsok
        {
            get
            {
                FaHalmaz<int> csucsok = new FaHalmaz<int>();
                for (int i = 0; i < n; i++)
                {
                    csucsok.Beszur(i);
                }
                return csucsok;
            }
        }

      
        public Halmaz<EgeszGrafEl> Elek
        {
            get
            {
                FaHalmaz<EgeszGrafEl> elek = new FaHalmaz<EgeszGrafEl>();
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (M[i, j])
                        {
                            elek.Beszur(new EgeszGrafEl(i, j));
                        }
                    }
                }
                return elek;
            }
        }

       
        public void UjEl(int honnan, int hova)
        {
            M[honnan, hova] = true;
        }

      
        public bool VezetEl(int honnan, int hova)
        {
            return M[honnan, hova];
        }





        public Halmaz<int> Szomszedai(int csúcs)
        {
            FaHalmaz<int> szomszedok = new FaHalmaz<int>();
            for (int j = 0; j < n; j++)
            {
                if (M[csúcs, j])
                {
                    szomszedok.Beszur(j);
                }
            }
            return szomszedok;
        }
    }

    // 3. 
    public static class GrafBejarasok
    {
 
        public static Halmaz<V> SzelessegiBejaras<V, E>(
            Graf<V, E> g,
            V start,
            Action<V> muvelet)
            where V : IComparable<V>
        {
            FaHalmaz<V> feldolgozott = new FaHalmaz<V>();
            TombSor<V> sor = new TombSor<V>(100);

            // 
            sor.Sorba(start);
            feldolgozott.Beszur(start);

            while (!sor.Ures)
            {
                V aktualis = sor.Sorbol();
                muvelet(aktualis);




                Halmaz<V> szomszedok = g.Szomszedai(aktualis);
                szomszedok.Bejar(szomszed =>
                {
                    if (!feldolgozott.Eleme(szomszed))
                    {
                        sor.Sorba(szomszed);
                        feldolgozott.Beszur(szomszed);
                    }
                });
            }

            return feldolgozott;
        }

        public static Halmaz<V> MelysegiBejaras<V, E>(
            Graf<V, E> g,
            V start,
            Action<V> muvelet)
            where V : IComparable<V>
        {
            FaHalmaz<V> feldolgozott = new FaHalmaz<V>();
            MelysegiBejarasRekurzio(g, start, feldolgozott, muvelet);
            return feldolgozott;
        }

        
        private static void MelysegiBejarasRekurzio<V, E>(
            Graf<V, E> g,
            V k,
            Halmaz<V> F,
            Action<V> muvelet)
            where V : IComparable<V>
        {
            if (F is FaHalmaz<V> faHalmaz)
            {
                faHalmaz.Beszur(k);
            }
            muvelet(k);

            // //
            Halmaz<V> szomszedok = g.Szomszedai(k);
            szomszedok.Bejar(szomszed =>
            {
                if (!F.Eleme(szomszed))
                {



                    MelysegiBejarasRekurzio(g, szomszed, F, muvelet);
                }
            });
        }
    }
}