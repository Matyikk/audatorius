﻿using System;

namespace OE.ALGA.Adatszerkezetek
{
    public class SzotarElem<K, T>
    {
        public K kulcs;
        public T tart;
        public SzotarElem(K kulcs, T tart)
        {
            this.kulcs = kulcs;
            this.tart = tart;
        }
    }

    public class HasitoSzotarTulcsordulasiTerulettel<K, T> : Szotar<K, T>
    {
        private SzotarElem<K, T>[] E;
        private Func<K, int> h;
        private LancoltLista<SzotarElem<K, T>> U;

        // MODOSITAS: uj mezo hozzaadva - egyedi kulcsok tarolasara
        private LancoltLista<SzotarElem<K, T>> egyediLista;

        public HasitoSzotarTulcsordulasiTerulettel(int meret, Func<K, int> hasitoFuggveny)
        {
            E = new SzotarElem<K, T>[meret];
            h = (x) => Math.Abs(hasitoFuggveny(x)) % E.Length;
            U = new LancoltLista<SzotarElem<K, T>>();

            // MODOSITAS: egyediLista inicializalasa
            egyediLista = new LancoltLista<SzotarElem<K, T>>();
        }

        public HasitoSzotarTulcsordulasiTerulettel(int meret)
            : this(meret, (x) => x.GetHashCode())
        {
        }

        public void Felszabadit()
        {
            E = null;
        }

        private SzotarElem<K, T> KulcsKeres(K kulcs)
        {
            int index = h(kulcs);
            if (E[index] != null && E[index].kulcs.Equals(kulcs))
            {
                return E[index];
            }

            for (int i = 0; i < U.Elemszam; i++)
            {
                SzotarElem<K, T> elem = U.Kiolvas(i);
                if (elem.kulcs.Equals(kulcs))
                {
                    return elem;
                }
            }
            return null;
        }

        public void Beir(K kulcs, T ertek)
        {
            SzotarElem<K, T> meglevo = KulcsKeres(kulcs);
            if (meglevo != null)
            {
                meglevo.tart = ertek;
                return;
            }

            SzotarElem<K, T> ujElem = new SzotarElem<K, T>(kulcs, ertek);
            int index = h(kulcs);

            if (E[index] == null)
            {
                E[index] = ujElem;

                // MODOSITAS: ha nem volt utkozes, egyediLista-ba is betesszuk
                egyediLista.Hozzafuz(ujElem);
            }
            else
            {
                U.Hozzafuz(ujElem);
            }
        }

        public T Kiolvas(K kulcs)
        {
            SzotarElem<K, T> elem = KulcsKeres(kulcs);
            if (elem != null)
            {
                return elem.tart;
            }
            else
            {
                throw new HibasKulcsKivetel();
            }
        }

        public void Torol(K kulcs)
        {
            int index = h(kulcs);
            if (E[index] != null && E[index].kulcs.Equals(kulcs))
            {
                E[index] = null;
                return;
            }

            for (int i = 0; i < U.Elemszam; i++)
            {
                SzotarElem<K, T> elem = U.Kiolvas(i);
                if (elem.kulcs.Equals(kulcs))
                {
                    U.Torol(elem);
                    return;
                }
            }
            throw new HibasKulcsKivetel();
        }

        // MODOSITAS: uj metodus hozzaadva
        public Lista<K> EgyediKulcsok(bool egyszeri, bool aktualis)
        {
            Lista<K> eredmeny = new LancoltLista<K>();

            for (int i = 0; i < egyediLista.Elemszam; i++)
            {
                SzotarElem<K, T> elem = egyediLista.Kiolvas(i);
                K kulcs = elem.kulcs;

                // Ha aktualis == true, ellenorizzuk hogy meg benne van-e a szotarban
                if (aktualis)
                {
                    SzotarElem<K, T> megvan = KulcsKeres(kulcs);
                    if (megvan == null)
                    {
                        continue;
                    }
                }

                // Ha egyszeri == true, csak egyszer szerepelhet egy kulcs
                if (egyszeri)
                {
                    bool benneVan = false;
                    for (int j = 0; j < eredmeny.Elemszam; j++)
                    {
                        if (eredmeny.Kiolvas(j).Equals(kulcs))
                        {
                            benneVan = true;
                            break;
                        }
                    }
                    if (!benneVan)
                    {
                        eredmeny.Hozzafuz(kulcs);
                    }
                }
                else
                {
                    eredmeny.Hozzafuz(kulcs);
                }
            }

            return eredmeny;
        }
    }
}