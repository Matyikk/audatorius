﻿using OE.ALGA.ALGAme;

Jatek jatek = new Jatek();
jatek.Start();